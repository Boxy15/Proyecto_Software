import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:proyecto_cine_equipo3/Modelo/CarritoCafeteria.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:proyecto_cine_equipo3/Vistas/Cafeteria/Ticket.dart';
import 'package:proyecto_cine_equipo3/Modelo/ModeloReceta.dart';
import 'package:proyecto_cine_equipo3/Modelo/CarritoCafeteria.dart';



Future<void> generarTicketPDF(
  double total,
  double recibido,
  double cambio,
  List<Producto> productos,
  List<Receta> combos,
) async {
  final pdf = pw.Document();

  final now = DateTime.now();
  final fecha = now.toString();

  pdf.addPage(
    pw.Page(
      build: (pw.Context context) {
        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text("🎬 PICHTO CINEMAS", style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
            pw.Text("Fecha: $fecha"),
            pw.Divider(),

            pw.Text("Productos:", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            if (productos.isEmpty)
              pw.Text(" - Ninguno")
            else
              ...productos.map((p) => pw.Text(" - ${p.nombre} (\$${p.precio.toStringAsFixed(2)})")).toList(),

            pw.SizedBox(height: 10),
            pw.Text("Combos:", style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            if (combos.isEmpty)
              pw.Text(" - Ninguno")
            else
              ...combos.map((c) => pw.Text(" - ${c.nombre} (\$${c.precio.toStringAsFixed(2)})")),

            pw.Divider(),
            pw.Text("Total: \$${total.toStringAsFixed(2)}"),
            pw.Text("Recibido: \$${recibido.toStringAsFixed(2)}"),
            pw.Text("Cambio: \$${cambio.toStringAsFixed(2)}"),
            pw.SizedBox(height: 20),
            pw.Text("¡Gracias por tu compra!"),
          ],
        );
      },
    ),
  );

  final output = await getApplicationDocumentsDirectory(); // compatible con Windows
  final file = File("${output!.path}/Ticket ${DateTime.now().millisecondsSinceEpoch}.pdf");
  await file.writeAsBytes(await pdf.save());
}


void main() {
  runApp(const SCafe());
}

class SCafe extends StatelessWidget {
  const SCafe({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: VentanaPagosC(),
    );
  }
}

class VentanaPagosC extends StatefulWidget {
  const VentanaPagosC({super.key});

  @override
  _VentanaPagosState createState() => _VentanaPagosState();
}

final montoRecibidoController = TextEditingController();
final cambioController = TextEditingController();

double total = 0.0;

class _VentanaPagosState extends State<VentanaPagosC> {
  @override
  void initState() {
    super.initState();
    // ▶︎ Calculamos el total al iniciar:
    final carrito = CarritoCafeteriaGlobal();
    total = carrito.productosSeleccionados
        .fold<double>(0.0, (sum, p) => sum + p.precio);
  }

  Widget TarjetaPelicula() {
    final items = CarritoCafeteriaGlobal().productosSeleccionados;
    if (items.isEmpty) {
      return const Text('No hay items en el carrito',
          style: TextStyle(color: Colors.white));
    }
    return Card(
      color: Colors.grey[200],
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Wrap(
          spacing: 10,
          runSpacing: 10,
          children: items.map((item) {
            final String imgPath = item.imagen ?? '';
            late final ImageProvider imgProvider;
            if (imgPath.isEmpty) {
              imgProvider = const AssetImage('images/default.png');
            } else if (imgPath.startsWith('http')) {
              imgProvider = NetworkImage(imgPath);
            } else {
              imgProvider = AssetImage(imgPath);
            }

            return Container(
              width: 100,
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: Colors.black12),
                image: DecorationImage(
                  image: imgProvider,
                  fit: BoxFit.cover,
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget SecciondePago() {
    bool esMiembro = false;
    bool usarCashback = false;

    return StatefulBuilder(
      builder: (ctx, setState) {
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: Colors.grey[200], borderRadius: BorderRadius.circular(10)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Checkbox(
                    value: esMiembro,
                    onChanged: (bool? value) {
                      setState(() {
                        esMiembro = value!;
                      });
                    },
                  ),
                  const Text(
                    'Miembros',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              if (esMiembro) ...[
                const SizedBox(height: 10),
                TextFields('Nombre'),
                const SizedBox(height: 10),
                TextFields('Apellido'),
                const SizedBox(height: 10),
                TextFields('Teléfono'),
                const SizedBox(height: 10),
                TextFields('Cashback'),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: usarCashback,
                      onChanged: (bool? value) {
                        setState(() {
                          usarCashback = value!;
                        });
                      },
                    ),
                    const Text(
                      'Usar Cashback',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ],
              // 1) Mostrar el total real
              Text('Total: \$${total.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),

              const SizedBox(height: 10),

              // 2) Monto recibido
              TextField(
                controller: montoRecibidoController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Monto Recibido',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(),
                ),
                onChanged: (val) {
                  final recibido = double.tryParse(val) ?? 0.0;
                  final cambio = recibido - total;
                  cambioController.text = cambio.toStringAsFixed(2);
                },
              ),

              const SizedBox(height: 10),

              // 3) Cambio (sólo lectura)
              TextField(
                controller: cambioController,
                decoration: const InputDecoration(
                  labelText: 'Cambio',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(),
                ),
                readOnly: true,
              ),

              const SizedBox(height: 20),

              // ── Tu botón Pagar sigue igual ──
              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton(
                  onPressed: () {
                    final recibido = double.tryParse(montoRecibidoController.text) ?? 0;
                    final cambio = recibido - total;
                    final productos = CarritoCafeteriaGlobal().productosSeleccionados;
                    final combos = <Receta>[]; // Replace with actual combos if available
                    generarTicketPDF(total, recibido, cambio, productos, combos);
                    CarritoCafeteriaGlobal().limpiar();
                    Navigator.pop(context); // o redirige donde quieras
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0665A4),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 15),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Pagar',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget TextFields(String label) {
    return TextField(
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(
          fontSize: 14,
          color: Colors.black54,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [Color(0xFF022044), Color(0xFF01021E)],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back,
                                  color: Colors.white),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              'Atras',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const Text(
                          'Pago',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: const Color(0xFF0665A4),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset(
                              'images/PICNITO LOGO.jpeg',
                              fit: BoxFit.contain,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Center(
                    child: Stack(
                      children: [
                        Container(
                          width: 900,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xff081C42),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 10,
                                offset: Offset(0, 5),
                              ),
                            ],
                          ),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                TarjetaPelicula(),
                                const SizedBox(height: 20),
                                SecciondePago(),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
